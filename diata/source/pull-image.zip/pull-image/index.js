const fetch = require('node-fetch');

const outcome = (promise) => {
    return promise
        .then(result => ({
            success: true,
            result
        }))
        .catch(error => ({
            success: false,
            error
        }));
};

exports.incomming = async (req, res) => {
  const payload = req.body.payload;

  const content = await fetch(payload.url, {
    headers: payload.headers
  });

  if (content.status === 200) {
    const body = await content.buffer();
    return res.status(content.status).send({body});
  }

  const core = await outcome(content.json());

  if (core.success) {
    return res.status(424).send(JSON.stringify(core.result));
  }

  res.status(424).send(JSON.stringify(core.error));

};
