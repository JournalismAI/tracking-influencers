const fetch = require('node-fetch');

const outcome = (promise) => {
    return promise
        .then(result => ({
            success: true,
            result
        }))
        .catch(error => ({
            success: false,
            error
        }));
};

function timeout(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

exports.incomming = async (req, res) => {

  const payload = req.body.payload;

  if (payload.spin) {
    await timeout(100);
    return res.status(200).send(JSON.stringify({status: 'ok'}));
  }

  const content = await fetch(payload.url, {
    headers: payload.headers
  });

  if (content.status === 200) {
    const data = await content.json();
    return res.status(content.status).send(JSON.stringify(data));
  }

  const core = await outcome(content.json());

  if (core.success) {
    return res.status(424).send(JSON.stringify(core.result));
  }

  res.status(content.status).send(JSON.stringify(core.error));

};
